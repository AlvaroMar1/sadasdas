<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="html" encoding="utf8" incident="yes"/>

    <xsl:template match="/">
        <html>
            <head>
                <title>hola</title>
            </head>
            <body>
                <h1>NOMBRE DEL INSTITUTO</h1>


                <h2>Seccion departamentos</h2>
                <table border="1">

                    <tr>
                        <th>Nombre del departamento</th>
                        <th>Jefe de departamento</th>
                        <th>Presupuesto</th>
                    </tr>

                    <xsl:for-each select="/instituto/departamentos/departamento">

                    <xsl:sort select="nombre" data-type="string" order="ascending"/>

                    <tr>
                        <td><xsl:value-of select="nombre"/></td> 
                        <td><xsl:value-of select="jefe_departamento"/></td>
                        <td><xsl:value-of select="presupuesto"/> €</td>
                        <td>
                            <xsl:if test="presupuesto &gt; 1000">
                            Presupuesto alto
                            </xsl:if>

                            <xsl:if test="presupuesto &lt; 1001">
                            Presupuesto bajo
                            </xsl:if>
                        </td>

                    </tr>

                    </xsl:for-each>

                </table>

                 <p><strong>TOTAL PRESUPUESTO: <xsl:value-of select="sum(/instituto/departamentos/departamento/presupuesto)"></xsl:value-of></strong></p>

                
                <h2>Seccion ciclos y modulos</h2>




                <xsl:for-each select="/instituto/ciclos/ciclo">

                    <xsl:value-of select="nombre"/>
                    <xsl:text> </xsl:text>
                    <xsl:value-of select="@id"/>
                    <xsl:text> </xsl:text>
                    <xsl:value-of select="@grado"/>
                    <xsl:text> </xsl:text>

                    
                <table border="1">

                    <tr>
                        <th>Identificador de modulo</th>
                        <th>Nombre</th>
                        <th>Curso</th>
                        <th>Horas</th>
                    </tr>

                    <xsl:for-each select="modulos/modulo">

                    <xsl:sort select="nombre" order="ascending"/>

                        <tr>
                            <td><xsl:value-of select="@id"/></td>
                            <td><xsl:value-of select="nombre"/></td>
                            <td><xsl:value-of select="@curso"/></td>
                            <td><xsl:value-of select="horas"/></td>
                            <td>
                                <xsl:if test="horas &gt; 100">
                                    <p>Modulo de carga alta</p>
                                </xsl:if>
                            </td>

                        </tr>
                
                    </xsl:for-each>

                    <tr>
                        <th></th>
                        <th></th>
                        
                        <th><p>Total Horas</p></th>
                        <th><xsl:value-of select="sum(modulos/modulo/horas)"/></th>
                    </tr>
                


                </table>

                </xsl:for-each>

            </body>
        </html>
    </xsl:template>
</xsl:stylesheet>
  
  